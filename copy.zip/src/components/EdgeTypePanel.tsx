import { Form } from 'react-bootstrap';

const EdgeTypePanel = ({ edgeType, setEdgeType }: { edgeType: string; setEdgeType: (type: string) => void }) => {
  return (
    <div className="p-3 border-bottom">
      <Form.Group>
        <Form.Label>Edge Type</Form.Label>
        <Form.Select value={edgeType} onChange={(e) => setEdgeType(e.target.value)}>
          <option value="default">Default</option>
          <option value="straight">Straight</option>
          <option value="step">Step</option>
          <option value="smoothstep">Smooth Step</option>
        </Form.Select>
      </Form.Group>
    </div>
  );
};

export default EdgeTypePanel;
