

import { Button, Navbar } from 'react-bootstrap';

const Toolbar = ({ onUndo, onRedo, canUndo, canRedo }: { onUndo: () => void; onRedo: () => void; canUndo: boolean; canRedo: boolean }) => {
  return (
    <Navbar bg="light" expand="lg" className="p-2 border-bottom">
      <Button variant="secondary" onClick={onUndo} disabled={!canUndo} className="me-2">
        Undo
      </Button>
      <Button variant="secondary" onClick={onRedo} disabled={!canRedo}>
        Redo
      </Button>
    </Navbar>
  );
};

export default Toolbar;
