import { useState } from 'react';
import { Card, Button } from 'react-bootstrap';

const ShapesPanel = () => {
    const [isCollapsed, setIsCollapsed] = useState(false);

    const onDragStart = (event: React.DragEvent, nodeType: string) => {
        event.dataTransfer.setData('application/reactflow', nodeType);
        event.dataTransfer.effectAllowed = 'move';
    };

    if (isCollapsed) {
        return (
            <div className="bg-light border-end">
                <Button onClick={() => setIsCollapsed(false)} variant="light">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-chevron-right" viewBox="0 0 16 16">
                        <path fillRule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
                    </svg>
                </Button>
            </div>
        )
    }

    return (
        <aside className="bg-light p-3 border-end d-flex flex-column" style={{width: '250px'}}>
            <div className="d-flex justify-content-between align-items-center mb-4">
                <h2 className="h5">SimpliProcess</h2>
                <Button onClick={() => setIsCollapsed(true)} variant="light">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" className="bi bi-chevron-left" viewBox="0 0 16 16">
                        <path fillRule="evenodd" d="M11.354 1.646a.5.5 0 0 1 0 .708L5.707 8l5.647 5.646a.5.5 0 0 1-.708.708l-6-6a.5.5 0 0 1 0-.708l6-6a.5.5 0 0 1 .708 0z"/>
                    </svg>
                </Button>
            </div>
            
            <h3 className="h6 text-muted mb-2">Flowchart</h3>
            <div className="d-grid gap-2">
                <Card 
                    className="p-3 text-center" 
                    onDragStart={(event) => onDragStart(event, 'start')} 
                    draggable
                >
                    Start
                </Card>
                <Card 
                    className="p-3 text-center" 
                    onDragStart={(event) => onDragStart(event, 'task')} 
                    draggable
                >
                    Task
                </Card>
                <Card 
                    className="p-3 text-center" 
                    onDragStart={(event) => onDragStart(event, 'decision')} 
                    draggable
                >
                    Decision
                </Card>
                <Card 
                    className="p-3 text-center" 
                    onDragStart={(event) => onDragStart(event, 'subProcess')} 
                    draggable
                >
                    Sub-process
                </Card>
                <Card 
                    className="p-3 text-center" 
                    onDragStart={(event) => onDragStart(event, 'end')} 
                    draggable
                >
                    End
                </Card>
            </div>
      </aside>
    );
}

export default ShapesPanel;